package hu.szalai.dominik.akasztofa;

public interface EsemenyKezelo {
	
	void esemeny(String azonosito);

}
